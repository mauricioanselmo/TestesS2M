package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectualDoNotSelect3Itens_1_3_CT08;


public class StatusCapitalIntelectualDoNotSelect3Itens_1_3_CT08 extends TestBase {
	@Test(description="1.3	CT08 – Validar que NÃO é possível selecionar três itens do resumo de distribuição das aplicações")
	public void primeiroteste() throws Exception {
		
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectualDoNotSelect3Itens_1_3_CT08.element_linkMenuCapital(getDriver()).click();
		Thread.sleep(12000);
		
		
		//clica no Filtro superior direito.
		assertTrue(PageObjectsCapitalIntelectualDoNotSelect3Itens_1_3_CT08.element_SumNota(getDriver()));
		Thread.sleep(1000);
		
		}
}
