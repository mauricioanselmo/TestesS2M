package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectualOrderBy_4_1_CT02;


public class StatusCapitalIntelectualOrderBy_4_1_CT02 extends TestBase {
	@Test(description="4.1	CT02 – Validar a ordenação apresentada das siglas da \"Lista de Aplicações\"")
	public void primeiroteste() throws Exception {
		
		setUrl();
		Thread.sleep(15000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectualOrderBy_4_1_CT02.element_linkMenuCapital(getDriver()).click();
		Thread.sleep(5500);
		
		//CLICA NO ÍCONE DE RESUMO
		PageObjectsCapitalIntelectualOrderBy_4_1_CT02.element_ResumeButton(getDriver()).click();
		Thread.sleep(4000);
		
		//Clica na TERCEIRA linha da lista.
		assertTrue(PageObjectsCapitalIntelectualOrderBy_4_1_CT02.element_CheckSortItens(getDriver()));
		Thread.sleep(9000);
		
		}
}
