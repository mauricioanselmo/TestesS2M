package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectualShowPopover_2_1_CT01;


public class StatusCapitalIntelectualShowPopover_2_1_CT01 extends TestBase {
	@Test(description="2.1	CT01 –  Validar que ao selecionar uma Sigla do gráfico é exibido um popover de dados")
	public void primeiroteste() throws Exception {
		
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectualShowPopover_2_1_CT01.element_linkMenuCapital(getDriver()).click();
		Thread.sleep(12000);
		
		//CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
		PageObjectsCapitalIntelectualShowPopover_2_1_CT01.element_ShowPopover(getDriver()).click();
		Thread.sleep(12000);
		
		
		//clica no Filtro superior direito.
		assertTrue(PageObjectsCapitalIntelectualShowPopover_2_1_CT01.element_TextValidation(getDriver()));
		Thread.sleep(1000);
		
		}
}
