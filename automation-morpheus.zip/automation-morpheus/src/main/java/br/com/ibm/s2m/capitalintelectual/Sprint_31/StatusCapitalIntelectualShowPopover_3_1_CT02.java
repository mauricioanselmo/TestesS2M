package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectualShowPopover_3_1_CT02;


public class StatusCapitalIntelectualShowPopover_3_1_CT02 extends TestBase {
	@Test(description="3.1	CT02 – Validar funcionalidade do gráfico de risco de conhecimento")
	public void primeiroteste() throws Exception {
		
		setUrl();
		Thread.sleep(15000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_linkMenuCapital(getDriver()).click();
		Thread.sleep(4500);
		
		//CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_ShowPopover(getDriver()).click();
		Thread.sleep(2000);
		
		//CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_ShowPopoverCapitalIntelectual(getDriver()).click();
		Thread.sleep(2000);
		
		//CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_ShowPopoverBackHome(getDriver()).click();
		Thread.sleep(2000);
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(5000);
		
		//Clica no capital Intelectual
		PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(5500);
		
		assertTrue(PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_ValidaTotalDaRegua(getDriver()));
		Thread.sleep(5000);
		
		
		//clica no Filtro superior direito.
	//	assertTrue(PageObjectsCapitalIntelectualShowPopover_3_1_CT02.element_TextValidation(getDriver()));
	//	Thread.sleep(1000);
		
		}
}
