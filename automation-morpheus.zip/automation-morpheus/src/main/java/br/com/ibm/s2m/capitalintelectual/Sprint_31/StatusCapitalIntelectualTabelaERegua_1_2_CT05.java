package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import java.util.Random;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05;


public class StatusCapitalIntelectualTabelaERegua_1_2_CT05 extends TestBase {
	@Test(description="1.2	CT05 – Validar que na régua é exibido um popover contendo a média das notas de capital intelectual por sigla")
	public void primeiroteste() throws Exception {
		
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(12000);
		
		//clica no Filtro superior direito.
		PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_ClickFilter(getDriver()).click();
		Thread.sleep(5000);
		
		//RETORNA TOTAL DE ITENS NO COMBO.
		int totalItens = PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_contaItensDoCombo(getDriver());
		System.out.println(totalItens);
		
		Random rand = new Random();
		int  n = rand.nextInt(totalItens) + 1;
		System.out.println("numero aleatório " + n);
		
		//clica no Gestor Responsável
				new Select(PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_UserFilterActionPlanGestorResponsavel(getDriver())).selectByIndex(n);
				Thread.sleep(1500);
		
		//CLICA NO BOTÃO APLICAR
				PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_ApplyButonActionPlan(getDriver()).click();
		Thread.sleep(2000);		
				
		//clica no Filtro superior direito.
		assertTrue(PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05.element_SumNota(getDriver()));
		Thread.sleep(1000);
		
		}
}
