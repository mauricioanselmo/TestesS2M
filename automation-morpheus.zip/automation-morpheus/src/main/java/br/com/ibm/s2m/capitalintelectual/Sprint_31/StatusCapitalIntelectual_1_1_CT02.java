package br.com.ibm.s2m.capitalintelectual.Sprint_31;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCapitalIntelectual_1_1_CT02;

public class StatusCapitalIntelectual_1_1_CT02 extends TestBase {
	@Test(description="1.1	CT02 – Validar a funcionalidade do Side Filter – Capital Intelectual")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		//Texto CAPITAL INTELECTUAL do menu principal
		PageObjectsCapitalIntelectual_1_1_CT02.element_linkMenuIntelectualCapital(getDriver()).click();
		Thread.sleep(10000);
		
		//Armazena o total atual de Aplicações
		PageObjectsCapitalIntelectual_1_1_CT02.element_ApplicationSum(getDriver()).click();
		Thread.sleep(1000);
		
		//clica no Filtro superior direito.
		PageObjectsCapitalIntelectual_1_1_CT02.element_ClickFilter(getDriver()).click();
		
	
		//clica no Gestor Responsável
		new Select(PageObjectsCapitalIntelectual_1_1_CT02.element_UserFilterActionPlanGestorResponsavel(getDriver())).selectByIndex(1);
		Thread.sleep(1500);
		
		//CLICA NO BOTÃO APLICAR
		PageObjectsCapitalIntelectual_1_1_CT02.element_ApplyButonActionPlan(getDriver()).click();
		Thread.sleep(2000);
		
		//VALIDA O VALOR DO TOTAL DE APLICAÇÕES E O GESTOR
		assertTrue(PageObjectsCapitalIntelectual_1_1_CT02.element_DivResultActionPlan(getDriver()).getText().contains("AIRTON OLIVEIRA")); 
	}
}