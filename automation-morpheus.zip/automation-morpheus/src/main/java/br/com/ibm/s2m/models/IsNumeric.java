package br.com.ibm.s2m.models;

public class IsNumeric {

    public static boolean isANumber(String number) {

        boolean numeric = true;

        try {
            Double num = Double.parseDouble(number);
        } catch (NumberFormatException e) {
            numeric = false;
        }
//
//        if(numeric)
//            System.out.println(number + " is a number");
//        else
//            System.out.println(number + " is not a number");
		return numeric;
    }
}