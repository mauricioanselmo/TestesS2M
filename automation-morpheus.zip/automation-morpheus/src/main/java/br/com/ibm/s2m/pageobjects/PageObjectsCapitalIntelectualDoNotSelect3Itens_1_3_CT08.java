package br.com.ibm.s2m.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;



//Texto CAPITAL INTELECTUAL do menu principal
public class PageObjectsCapitalIntelectualDoNotSelect3Itens_1_3_CT08 {
	WebElement element;

	public static WebElement element_linkMenuCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
		// SOMA CONTEÚDO DA TABELA NOTA TOTAL COLUNA 7.
	public static boolean element_SumNota(WebDriver driver) {
		WebElement element;
		boolean retorno = false;
		
		
//		ArrayList<String> notaTotalTabela = new ArrayList<>();
		
		try {
			
			//CLICA NO PRIMEIRO ELEMENTO AGUARDA O FOCO E PEGA A COR EM RGBA E HEXADECIMAL
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[1]/button"));
			element.click();
			Thread.sleep(1200);
			String corBotao1 = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[1]/button")).getCssValue("background-color");
		//	System.out.println("A cor do primeiro botão é " + corBotao1);
			String hexa1 = Color.fromString(corBotao1).asHex();
		//	System.out.println("Seu hexa é " + hexa1 + "\n");
			
			//CLICA NO SEGUNDO ELEMENTO AGUARDA O FOCO E PEGA A COR EM RGBA E HEXADECIMAL
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[2]/button"));
			element.click();
			Thread.sleep(1200);
			String corBotao2 = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[2]/button")).getCssValue("background-color");
		//	System.out.println("A cor do segundo botão é  " + corBotao2);
			String hexa2 = Color.fromString(corBotao2).asHex();
		//	System.out.println("Seu hexa é " + hexa2 + "\n");
			
			//CLICA NO TERCEIRO ELEMENTO AGUARDA O FOCO E PEGA A COR EM RGBA E HEXADECIMAL
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[3]/button"));
			element.click();
			Thread.sleep(1200);
			String corBotao3 = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[3]/button")).getCssValue("background-color");
		//	System.out.println("A cor do terceiro botão é  " + corBotao3);
			String hexa3 = Color.fromString(corBotao3).asHex();
		//	System.out.println("Seu hexa é " + hexa3 + "\n");
			
			//VERIFICA A COR DO PRIMEIRO ELEMENTO APÓS CLICAR NOS 3
			String corBotao1Depois = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[1]/button")).getCssValue("background-color");
		//	System.out.println("A cor do primeiro botão é " + corBotao1Depois);
			String hexa1Depois = Color.fromString(corBotao1Depois).asHex();
		//	System.out.println("Seu hexa é " + hexa1Depois + "\n");
			
			//VERIFICA A COR DO SEGUNDO ELEMENTO APÓS CLICAR NOS 3
			String corBotao2Depois = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[2]/button")).getCssValue("background-color");
		//	System.out.println("A cor do segundo botão é " + corBotao2Depois);
			String hexa2Depois = Color.fromString(corBotao2Depois).asHex();
		//	System.out.println("Seu hexa é " + hexa2Depois + "\n");

			//VERIFICA A COR DO TERCEIRO ELEMENTO APÓS CLICAR NOS 3
			String corBotao3Depois = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[3]/button")).getCssValue("background-color");
		//	System.out.println("A cor do terceiro botão é " + corBotao3Depois);
			String hexa3Depois = Color.fromString(corBotao3Depois).asHex();
		//	System.out.println("Seu hexa é " + hexa3Depois + "\n");
			
		//	System.out.println("FALSO? 1 com 1 ");
		//	System.out.println(hexa1.equals(hexa1Depois));
		//	System.out.println("VERDADEIRO 3 com 3 ");
		//	System.out.println(hexa3.equals(hexa3Depois));
			
			//TESTAS OS VALORES HEXA APÓS CADA CLIQUE E POSTERIORMENTE CADA UM SEM CLIQUES CASO IGUAIS É UM ERRO.
			if (hexa1.equals(hexa1Depois) && (hexa2.equals(hexa2Depois) && (hexa3.equals(hexa3Depois)))){
				retorno = false;
			}else {
				retorno = true;
			}
			
			} catch (Exception e) {
			e.getMessage();
		}
		return retorno;
	}	
}