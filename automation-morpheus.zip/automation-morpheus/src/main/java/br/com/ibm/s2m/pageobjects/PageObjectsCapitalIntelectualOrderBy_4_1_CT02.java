package br.com.ibm.s2m.pageobjects;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import br.com.ibm.s2m.models.IsNumeric;


//Texto CAPITAL INTELECTUAL do menu principal
public class PageObjectsCapitalIntelectualOrderBy_4_1_CT02 {
	WebElement element;
	public static String capitalIntelectual, linhaDePesquisa;

	public static WebElement element_linkMenuCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA NO ÍCONE DE RESUMO
	public static WebElement element_ResumeButton(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/ul/li[2]/button"));
			System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// SELECIONA ITENS DA TABELA ADICIONA CONFERE ORDENAÇÃO E PRINTA RESULTADO
	public static boolean element_CheckSortItens(WebDriver driver) {
		LinkedList <String> listaOriginal = new LinkedList <>(); 
		LinkedList <String> listaOrdenada = new LinkedList <>(); 
		
		boolean retorno = false;
		try {
			
			List<WebElement> elementList = driver.findElements(By.className("col-application"));
			List<WebElement> notaFinal = driver.findElements(By.className("col-final-score"));

	//		System.out.println("Aplicações " + elementList.size());
	//		System.out.println("Notas " + notaFinal.size());
	
			elementList.remove(0);
			notaFinal.remove(0);
			
	//		System.out.println("Novo total de Aplicações " + elementList.size());
	//		System.out.println("Novo total de Notas " + notaFinal.size());
			
			long tempoInicial = System.currentTimeMillis();
	//	    System.out.printf("%.3f segundos%n", (tempoInicial) / 1000d);
			
			int i;
			for (i=0; i < elementList.size(); i++) {
				if (IsNumeric.isANumber(elementList.get(i).getText())) {
					listaOriginal.add(i, elementList.get(i).getText()+""+notaFinal.get(i).getText());
	//				System.out.println(listaOriginal.get(i));
				}else {
					listaOriginal.add(i, notaFinal.get(i).getText()+""+elementList.get(i).getText());
	//				System.out.println(listaOriginal.get(i));
				}		
			}
			
			
			long tempoFinal = System.currentTimeMillis();
	//	    System.out.printf("%.3f segundos%n", (tempoFinal - tempoInicial) / 1000d);
		    
		    listaOrdenada.addAll(0, listaOriginal);
			Collections.sort(listaOrdenada); 
			if(listaOrdenada.equals(listaOriginal))
				retorno = true;
			
	//		System.out.println("O que deu o retorno? " + retorno);


		} catch (

		Exception e) {
			e.getMessage();
		}
		return retorno;
	}

	
	
}