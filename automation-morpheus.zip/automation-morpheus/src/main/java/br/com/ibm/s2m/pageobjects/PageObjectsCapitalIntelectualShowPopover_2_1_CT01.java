package br.com.ibm.s2m.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//Texto CAPITAL INTELECTUAL do menu principal
public class PageObjectsCapitalIntelectualShowPopover_2_1_CT01 {
	WebElement element;

	public static WebElement element_linkMenuCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
	public static WebElement element_ShowPopover(WebDriver driver) {
        WebElement element = null;
        try {
            element = driver.findElement(By.cssSelector("body > lib-common > div.mdl-layout__container > div > main > div > lib-s2m-enterprise-architecture > div > intellectual-capital-view > section > div > div:nth-child(4) > intellectual-capital-chart > div > div > div.chart-position > nvd3 > svg > g > g > g.nv-scatterWrap.nvd3-svg > g > g:nth-child(2) > g.nv-groups > g.nv-group.nv-series-2"));
            System.out.println(element.getText());
        } catch (Exception e) {
            e.getMessage();
        }
        return element;
    }


	// PESQUISA NO POPOVER TEXTO DEFAULT PARA VALIDAR A EXIBIÇÃO EM TELA
	public static boolean element_TextValidation(WebDriver driver) {
		boolean isTheTextPresent=false;
		try {
			isTheTextPresent = driver.getPageSource().contains("Ver ficha completa");
		//	System.out.println("encontrou? " + isTheTextPresent);
		} catch (Exception e) {
			e.getMessage();
		}
		return isTheTextPresent;
	}

	// element = driver.findElement(By.linkText("Ver ficha completa"));
//	Thread.sleep(1200);
//	String achou = element.getText();
//	System.out.println("parte 2");
//	System.out.println("O que printa " + achou);
//				if (achou.equals("Ver ficha completa")){
//		retorno = true;
//	}else {
//		retorno = false;
//	}
//	

}