package br.com.ibm.s2m.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//Texto CAPITAL INTELECTUAL do menu principal
public class PageObjectsCapitalIntelectualShowPopover_3_1_CT02 {
	WebElement element;
	public static String capitalIntelectual, linhaDePesquisa;

	public static WebElement element_linkMenuCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA EM UMA SIGLA BALÃO EXIBIDA NO GRÁFICO
	public static WebElement element_ShowPopover(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.cssSelector(
					"body > lib-common > div.mdl-layout__container > div > main > div > lib-s2m-enterprise-architecture > div > intellectual-capital-view > section > div > div:nth-child(4) > intellectual-capital-chart > div > div > div.chart-position > nvd3 > svg > g > g > g.nv-scatterWrap.nvd3-svg > g > g:nth-child(2) > g.nv-groups > g.nv-group.nv-series-2"));
			System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// ARMAZENA CONTEÚDO DO CAPITAL INTELECTUAL E LINHA A SER PESQUISADA NO COCKIPIT
	public static WebElement element_ShowPopoverCapitalIntelectual(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/intellectual-capital-chart/div/div/div[2]/div/ul/li[1]/span"));
			capitalIntelectual = element.getText()+",0";
			System.out.println(capitalIntelectual);

			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[3]/intellectual-capital-chart/div/div/div[2]/div/p[2]"));
			linhaDePesquisa = element.getText();
			System.out.println(linhaDePesquisa);

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// VOLTA A HOME
	public static WebElement element_ShowPopoverBackHome(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/nav/div/div/custom-breadcrumb/ol/li[1]/a"));
			System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA NO COCKIPIT DO GESTOR
	public static WebElement element_linkMenuCockpit(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("COCKPIT DO GESTOR"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// SELECIONA TERCEIRO ITEM DA TABELA
	public static WebElement element_FilterIndexActionPlanGR(WebDriver driver) {
		WebElement element = null;
		try {
			List<WebElement> descricao = driver.findElements(By.className("description"));	
			System.out.println("tamanho da tabela " + descricao.size());
			
			for (int i = 1; i < descricao.size(); i++) {
				
				if (descricao.get(i).getText().equals(linhaDePesquisa)){
					element = descricao.get(i);
					System.out.println("sai");
					break;
				}
			} 
			
			
//			
//			
//			WebElement table_element = driver.findElement(By.className("acronym-management-list"));
//			List<WebElement> tr_collection = table_element.findElements(By.tagName("tr"));
//			// List<WebElement>
//			// tr_collection=table_element.findElements(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/manager-cockpit-view/section/section/section[3]/acronym-list/section/div[2]/table/tbody/tr[1]"));
//
//			// System.out.println("NUMBER OF ROWS IN THIS TABLE = "+tr_collection.size());
//
//			int row_num = 1;
//			boolean parada = false;
//			for (WebElement trElement : tr_collection) {
//				List<WebElement> td_collection = trElement.findElements(By.className("description"));
//				System.out.println("NUMBER OF LINES=" +tr_collection.size());
//				System.out.println("NUMBER OF COLUMNS="+td_collection.size());
//				tr_collection.remove(0);
//				System.out.println(tr_collection.get(0).getText());
//				tr_collection.remove(0);
//				System.out.println(tr_collection.get(0).getText());
//				
//				for (WebElement tdElement : td_collection) {
//					System.out.println(td_collection.size());
//					 System.out.println(tdElement.getText());
//					if (tdElement.getText().equals(linhaDePesquisa)) {
//						parada = true;
//						element = tdElement;
//						System.out.println(element.getText());
//						break;
//					}
//				}
//				if (parada) {
//					break;
//				} else {
//					row_num++;
//				}
			

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA NO LINK CAPITAL INTELECTUAL
	public static WebElement element_IntelectualCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/ul/li[4]"));
			System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CONFERE MUDANÇA TOTAL DA REGUA
	public static boolean element_ValidaTotalDaRegua(WebDriver driver) {
		WebElement element = null;
		boolean retorno = false;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-ruler/div/div/div[1]"));
			System.out.println(element.getText());
			if (capitalIntelectual.equals(element.getText()))
				retorno = true;
		} catch (Exception e) {
			e.getMessage();
		}
		return retorno;
	}

}