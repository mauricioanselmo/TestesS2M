package br.com.ibm.s2m.pageobjects;

import java.text.DecimalFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;



//Texto CAPITAL INTELECTUAL do menu principal
public class PageObjectsCapitalIntelectualTabelaERegua_1_2_CT05 {
	WebElement element;

	public static WebElement element_linkMenuCockpit(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	
	//Clica no filtro para escolha do gestor
	public static WebElement element_ClickFilter(WebDriver driver) {
		WebElement element = null;
		try {
			 element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/nav/div/ul/li[3]/side-filter-button/button"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	//CONTA ITENS DO COMBO GESTOR DA APLICACAO
	public static int element_contaItensDoCombo(WebDriver driver) {
		int itemSize = 0;
		try {
			Select dropDown = new Select(driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/ng-component/div/div[1]/select")));
			
	        List <WebElement> elementCount = dropDown.getOptions();
	        itemSize = elementCount.size();
	        System.out.println("Numero de ítens no combo " + itemSize);
	        
	        //MOSTRA NOME DE TODOS OS GESTORES
//	        for(int i = 0; i < itemSize ; i++){
//	            String optionsValue = elementCount.get(i).getText();
//	            System.out.println(optionsValue);
//	        }
	        
		} catch (Exception e) {
			e.getMessage();
		}
		return itemSize;
	}
	
	public static WebElement element_UserFilterActionPlanGestorResponsavel(WebDriver driver) {
		WebElement element = null;
		try {
			 element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/ng-component/div/div[1]/select"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	public static WebElement element_ApplyButonActionPlan(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/div/button[2]"));
		} catch (Exception e) {                    
			e.getMessage();
		}
		return element;
	}

	// SOMA CONTEÚDO DA TABELA NOTA TOTAL COLUNA 7.
	public static boolean element_SumNota(WebDriver driver) {
		WebElement element;
		boolean retorno = false;
		
		double totalTabela = 0;
		String mediaTabela;
//		ArrayList<String> notaTotalTabela = new ArrayList<>();
		
		try {
			List<WebElement> notaTotal = driver.findElements(By.className("col-final-score"));	
			System.out.println("tamanho da tabela " + notaTotal.size());
			if (notaTotal.size() <= 1) {
				retorno = true;
			}

			for (int i = 1; i < notaTotal.size(); i++) {
				//System.out.println("valor da linha"+ notaTotal.get(i).getText());
				totalTabela = totalTabela + Double.parseDouble(notaTotal.get(i).getText().replace(',', '.'));
				} 
//			System.out.println("total da tabela = " + totalTabela);
//			System.out.println("média da tabela para bater na regua " + (totalTabela / (notaTotal.size() - 1)));
			
			DecimalFormat value = new DecimalFormat("#.#");
			mediaTabela = value.format(totalTabela / (notaTotal.size() - 1));
			 
//			System.out.println("media da tabela como string " + mediaTabela);
			
					element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[2]/score-ruler/div/div/div[1]"));
//					System.out.println("são iguais? " + mediaTabela.equals(element.getText()));
					if(mediaTabela.equals(element.getText()) || mediaTabela.equals("0"))
						retorno = true;
					
		} catch (Exception e) {
			e.getMessage();
		}
		return retorno;
	}
	
}
