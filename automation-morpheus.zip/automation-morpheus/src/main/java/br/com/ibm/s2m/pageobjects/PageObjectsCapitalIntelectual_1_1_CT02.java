package br.com.ibm.s2m.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PageObjectsCapitalIntelectual_1_1_CT02 {
	
	public static String totalDeAplicacoes;
	
	public static WebElement element_linkMenuIntelectualCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("CAPITAL INTELECTUAL"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	public static WebElement element_ApplicationSum(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[1]/p/span"));
			totalDeAplicacoes = element.getText();
			System.out.println("Total anterior de Aplicações " + totalDeAplicacoes);
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
		
	public static WebElement element_ClickFilter(WebDriver driver) {
		WebElement element = null;
		try {
			 element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/nav/div/ul/li[3]/side-filter-button/button"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	//CLICA NO GESTOR RESPONSÁVEL
	public static WebElement element_UserFilterActionPlanGestorResponsavel(WebDriver driver) {
		WebElement element = null;
		try {
			 element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/ng-component/div/div[1]/select"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}
	
	//CLICA NO BOTÃO APLICAR
	public static WebElement element_ApplyButonActionPlan(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/div/button[2]"));
		} catch (Exception e) {                    
			e.getMessage();
		}
		return element;
	}
	
	
	public static WebElement element_DivResultActionPlan(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[1]/p/span"));
			System.out.println("Novo total de aplicações " + element.getText());
			if (totalDeAplicacoes.equals(element.getText()))
					return element;
			element = driver.findElement(By.xpath("/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/intellectual-capital-view/section/div/div[1]/div/side-filter-chips/div/div"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}	
}


// 