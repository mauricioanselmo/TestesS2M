package br.com.ibm.s2m.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//Texto  COCKIPIT DO GESTOR do menu principal
public class PageObjectsUpdateBeforeDelete_4_2_CT04 {

	public static String totalRegua, novoTotal;

	public static WebElement element_linkMenuCockpit(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.linkText("COCKPIT DO GESTOR"));

		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// clica no Filtro superior direito.
	public static WebElement element_FilterIndexCockipit(WebDriver driver) {

		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/nav/div/ul/li[3]/side-filter-button/button"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// seleciona gestor
	public static WebElement element_FilterIndexCockipitGestor(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/ng-component/div/select"));
			// System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	public static WebElement element_ApplyCockipit(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/top-bar/div/side-filter/div/div[1]/div[2]/div/button[2]"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// SELECIONA TERCEIRO ITEM DA TABELA
	public static WebElement element_FilterIndexActionPlanGR(WebDriver driver) {
		WebElement element = null;
		try {

			WebElement baseTable = driver.findElement(By.className("acronym-management-list"));
			WebElement tableRow = baseTable.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/manager-cockpit-view/section/section/section[3]/acronym-list/section/div[2]/table/tbody/tr[3]"));
			String rowtext = tableRow.getText();
			System.out.println("Third row of table : " + rowtext);

			// to get 3rd row's 2nd column data
			element = tableRow.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/manager-cockpit-view/section/section/section[3]/acronym-list/section/div[2]/table/tbody/tr[3]/td[2]"));
			String valueIneed = element.getText();
			System.out.println("Cell value is : " + valueIneed);
			// cellIneed.click();
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA NO LINK CAPITAL INTELECTUAL
	public static WebElement element_IntelectualCapital(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/ul/li[4]"));
			System.out.println(element.getText());
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// ARMAZENA TOTAL DA REGUA TESTA SE ZERADO E RETORNA PARA VARIÁVEL GLOBAL
	public static WebElement element_VerifyZeroRule(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-ruler/div/div/div[1]"));

			System.out.println(element.getText());
			totalRegua = element.getText();
//				System.out.println("Antigo Total da Régua " + totalRegua);
//				System.out.println("Total Régua " + totalRegua);
//				System.out.println("Verdadeiro ou falso = " + totalRegua.equals("0,0"));
			if (totalRegua.equals("0,0"))
				return element;
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	public static boolean parar() {
		if (totalRegua.equals("0,0"))
			return true;
		return false;
	}

	// CLICA NO BOTÃO EDITAR NÍVEL DE CONHECIMENTO
	public static WebElement element_EditLevel(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-list/table/tbody/tr/td[8]/div/i"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CLICA NO BOTÃO EXCLUIR
	public static WebElement element_SelectDelete(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-list/table/tbody/tr/td[8]/div/ul/li[3]"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	public static WebElement element_SelectOkClick(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath("/html/body/lib-common/popup/div/div/div[3]/button[2]"));
		} catch (Exception e) {
			e.getMessage();
		}
		return element;
	}

	// CONFERE MUDANÇA TOTAL DA REGUA
	public static boolean element_ValidaTotalDaRegua(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-ruler/div/div/div[1]"));
			System.out.println(element.getText());
			if (totalRegua.equals(novoTotal))
				return false;
			novoTotal = element.getText();
			System.out.println("Novo Total da Régua " + novoTotal);
		} catch (Exception e) {
			e.getMessage();
		}
		return true;
	}

	public static boolean element_ValidaRuleZero(WebDriver driver) {
		WebElement element = null;
		try {
			element = driver.findElement(By.xpath(
					"/html/body/lib-common/div[1]/div/main/div/lib-s2m-enterprise-architecture/div/app-acronym-sheet-view/section/section[2]/tabs/div/wrapper[4]/div/knowledge-map-view/section/div/knowledge-map-ruler/div/div/div[1]"));
			System.out.println(element.getText());
			novoTotal = element.getText();
			if (totalRegua.equals(novoTotal))
				return true;
			novoTotal = element.getText();
			System.out.println("Novo Total da Régua " + novoTotal);
		} catch (Exception e) {
			e.getMessage();
		}
		return false;
	}
}
