package br.com.s2m.statusactionplan.Sprint_029;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsStatusActionPlan_3_2_CT03;

public class StatusActionPlan_3_2_CT03 extends TestBase {
	@Test(description="3.2	CT03 – Validar o filtro Gestor responsável (N2) quando o usuário filtrar um Gestor de Aplicação (N1)")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		//Texto Status plano de ação do menu principal
		PageObjectsStatusActionPlan_3_2_CT03.element_linkMenuActionPlan(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Filtro superior direito.
		PageObjectsStatusActionPlan_3_2_CT03.element_FilterIndexActionPlan(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Gestor da Aplicação
		new Select(PageObjectsStatusActionPlan_3_2_CT03.element_UserFilterActionPlanGestorAplicacao(getDriver())).selectByIndex(2);
		Thread.sleep(15000);
		
		//clica no Gestor Responsável
		new Select(PageObjectsStatusActionPlan_3_2_CT03.element_UserFilterActionPlanGestorResponsavel(getDriver())).selectByIndex(1);
		Thread.sleep(15000);
		
		PageObjectsStatusActionPlan_3_2_CT03.element_ApplyButonActionPlan(getDriver()).click();
		Thread.sleep(20000);
		Metods.waitElementDivStatusActionPlan(driver);
		assertTrue(PageObjectsStatusActionPlan_3_2_CT03.element_DivResultActionPlan(getDriver()).getText().contains("AILTON RICIOPO")); 
	}
}