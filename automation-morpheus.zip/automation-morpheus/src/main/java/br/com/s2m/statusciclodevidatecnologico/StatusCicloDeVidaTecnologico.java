package br.com.s2m.statusciclodevidatecnologico;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCicloDeVidaTecnologico;


public class StatusCicloDeVidaTecnologico extends TestBase {
	@Test
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsCicloDeVidaTecnologico.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Filtro superior direito.
		PageObjectsCicloDeVidaTecnologico.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		//clica no Gestor da Aplicação
		new Select(PageObjectsCicloDeVidaTecnologico.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(7);;
		Thread.sleep(1000);
		
		//clica no APLICAR 
		PageObjectsCicloDeVidaTecnologico.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsCicloDeVidaTecnologico.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		//Clica no capital Intelectual
		PageObjectsCicloDeVidaTecnologico.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);
		
//		PageObjectsCicloDeVidaTecnologico.element_EditLevel(getDriver()).click();
//		Thread.sleep(1000);
//		
//		new Select(PageObjectsCicloDeVidaTecnologico.element_SelectLevel(getDriver())).selectByIndex(3);;
//		Thread.sleep(1000);
//		
//		PageObjectsCicloDeVidaTecnologico.element_SelectSave(getDriver()).click();
//		Thread.sleep(1000);
		
	}
}