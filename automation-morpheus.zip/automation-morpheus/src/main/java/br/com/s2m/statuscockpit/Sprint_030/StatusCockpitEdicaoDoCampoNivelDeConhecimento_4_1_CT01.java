package br.com.s2m.statuscockpit.Sprint_030;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsBatimentoRegua_4_1_CT01;


public class StatusCockpitEdicaoDoCampoNivelDeConhecimento_4_1_CT01 extends TestBase {
	@Test(description="4.1	CT01 – Realizar edição do campo Nível de Conhecimento")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsBatimentoRegua_4_1_CT01.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Filtro superior direito.
		PageObjectsBatimentoRegua_4_1_CT01.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		//clica no Gestor da Aplicação
		new Select(PageObjectsBatimentoRegua_4_1_CT01.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(7);;
		Thread.sleep(1000);
		
		//clica no APLICAR 
		PageObjectsBatimentoRegua_4_1_CT01.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsBatimentoRegua_4_1_CT01.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		//Clica no capital Intelectual
		PageObjectsBatimentoRegua_4_1_CT01.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);
		
		PageObjectsBatimentoRegua_4_1_CT01.element_CopiaTotalDaRegua(getDriver()).click();
		Thread.sleep(1000);
		
		String totalDaRegua;
		totalDaRegua = PageObjectsBatimentoRegua_4_1_CT01.element_CopiaTotalDaRegua(getDriver()).getText();
		//System.out.println("total da regua no Status " + totalDaRegua);
		
		if (totalDaRegua.equals("0,0")){
			assertTrue(true);
		}
		else
		{
		PageObjectsBatimentoRegua_4_1_CT01.element_EditLevel(getDriver()).click();
		Thread.sleep(1000);
		
		new Select(PageObjectsBatimentoRegua_4_1_CT01.element_SelectLevel(getDriver())).selectByIndex(3);;
		Thread.sleep(1000);
		
		PageObjectsBatimentoRegua_4_1_CT01.element_SelectSave(getDriver()).click();
		Thread.sleep(1000);
		
		assertTrue(PageObjectsBatimentoRegua_4_1_CT01.element_ValidaTotalDaRegua(getDriver()));
		Thread.sleep(8000);

		}
		
	}
}