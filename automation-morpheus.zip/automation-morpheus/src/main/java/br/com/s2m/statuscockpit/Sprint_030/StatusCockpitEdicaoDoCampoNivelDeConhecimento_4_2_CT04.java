package br.com.s2m.statuscockpit.Sprint_030;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsUpdateBeforeDelete_4_2_CT04;

public class StatusCockpitEdicaoDoCampoNivelDeConhecimento_4_2_CT04 extends TestBase {
	@Test(description = "1.1	CT02 – Validar a funcionalidade do Side Filter – Capital Intelectual")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());

		// Texto COCKIPIT DO GESTOR do menu principal
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(15000);

		// clica no Filtro superior direito.
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		// clica no Gestor da Aplicação
		new Select(PageObjectsUpdateBeforeDelete_4_2_CT04.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(7);
		
		Thread.sleep(1000);

		// clica no APLICAR
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);

		// Clica na TERCEIRA linha da lista.
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		// Metods.waitElementFilterIndexActionPlanGR(getDriver());

		// Clica no capital Intelectual
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);

		// Verifica se a regua está zerada
		PageObjectsUpdateBeforeDelete_4_2_CT04.element_VerifyZeroRule(getDriver()).click();
		
		boolean finalizarSemColaborador = PageObjectsUpdateBeforeDelete_4_2_CT04.parar();
	//	System.out.println("O que traz no continuar? " + finalizarSemColaborador);
		if (finalizarSemColaborador == true) {
			assertTrue(PageObjectsUpdateBeforeDelete_4_2_CT04.element_ValidaRuleZero(getDriver()));
		} else {
			// CLICA NO BOTÃO EDITAR
			PageObjectsUpdateBeforeDelete_4_2_CT04.element_EditLevel(getDriver()).click();
			Thread.sleep(1000);

			PageObjectsUpdateBeforeDelete_4_2_CT04.element_SelectDelete(getDriver()).click();
			Thread.sleep(4000);

			PageObjectsUpdateBeforeDelete_4_2_CT04.element_SelectOkClick(getDriver()).click();
			Thread.sleep(2000);

			assertTrue(PageObjectsUpdateBeforeDelete_4_2_CT04.element_ValidaTotalDaRegua(getDriver()));
			Thread.sleep(8000);
		}
	}

}