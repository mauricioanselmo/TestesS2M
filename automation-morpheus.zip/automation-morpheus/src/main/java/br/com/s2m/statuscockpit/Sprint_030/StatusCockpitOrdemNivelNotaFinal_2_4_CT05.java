package br.com.s2m.statuscockpit.Sprint_030;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05;


public class StatusCockpitOrdemNivelNotaFinal_2_4_CT05 extends TestBase {
	@Test(description="2.4	CT05 – Validar a nota de conhecimento individual de um funcionário")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Filtro superior direito.
		PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		//clica no Gestor da Aplicação
		new Select(PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(7);;
		Thread.sleep(1000);
		
		//clica no APLICAR 
		PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		//Clica no capital Intelectual
		PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);
		
		//Clica na PRIMEIRA linha FICHA DA SIGLAa.
				assertTrue(PageObjectsCockpitOrdemNivelNotaFinal_2_4_CT05.element_SumFichaDaSigla(getDriver()));
				Thread.sleep(8000);
				//Metods.waitElementFilterIndexActionPlanGR(getDriver());
	}
}