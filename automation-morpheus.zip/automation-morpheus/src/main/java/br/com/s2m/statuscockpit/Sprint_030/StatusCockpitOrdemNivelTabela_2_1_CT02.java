package br.com.s2m.statuscockpit.Sprint_030;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCockpitOrdemNivelTabela_2_1_CT02;


public class StatusCockpitOrdemNivelTabela_2_1_CT02 extends TestBase {
	@Test(description="2.1	CT02 – Validar a ordem de apresentação dos colaboradores conforme nível de conhecimento da Lista de Colaboradores")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(15000);
		
		//clica no Filtro superior direito.
		PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		//clica no Gestor da Aplicação
		new Select(PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(7);;
		Thread.sleep(1000);
		
		//clica no APLICAR 
		PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		//Clica no capital Intelectual
		PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);
		
		//Clica na PRIMEIRA linha FICHA DA SIGLAa.
				assertTrue(PageObjectsCockpitOrdemNivelTabela_2_1_CT02.element_SumFichaDaSigla(getDriver()));
				Thread.sleep(8000);
				//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		}
}
