package br.com.s2m.statuscockpit.Sprint_030;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import br.com.ibm.s2m.models.Metods;
import br.com.ibm.s2m.models.TestBase;
import br.com.ibm.s2m.pageobjects.PageObjectsCockpitTotalTabelaERegua_1_3_CT06;


public class StatusCockpitTotalTabelaERegua_1_3_CT06 extends TestBase {
	@Test(description="1.3	CT06 –  Validar a nota da aplicação informada no popover da Régua - Capital Intelectual")
	public void primeiroteste() throws Exception {
		setUrl();
		Thread.sleep(10000);
		Metods.waitElementOverviewLink(getDriver());
		
		// Texto  COCKIPIT DO GESTOR do menu principal
		PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_linkMenuCockpit(getDriver()).click();
		Thread.sleep(12000);
		
		//clica no Filtro superior direito.
		PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_FilterIndexCockipit(getDriver()).click();
		Thread.sleep(1000);

		//clica no Gestor da Aplicação
		new Select(PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_FilterIndexCockipitGestor(getDriver())).selectByIndex(12);;
		Thread.sleep(1000);
		
		//clica no APLICAR 
		PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_ApplyCockipit(getDriver()).click();
		Thread.sleep(8000);
		
		//Clica na TERCEIRA linha da lista.
		PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_FilterIndexActionPlanGR(getDriver()).click();
		Thread.sleep(8000);
		//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		//Clica no capital Intelectual
		PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_IntelectualCapital(getDriver()).click();
		Thread.sleep(1000);
		
		//Clica na PRIMEIRA linha FICHA DA SIGLAa.
				assertTrue(PageObjectsCockpitTotalTabelaERegua_1_3_CT06.element_SumFichaDaSigla(getDriver()));
				Thread.sleep(8000);
				//Metods.waitElementFilterIndexActionPlanGR(getDriver());
		
		}
}
